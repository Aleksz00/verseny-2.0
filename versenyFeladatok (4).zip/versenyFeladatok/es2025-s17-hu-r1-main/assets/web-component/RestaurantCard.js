/*
 * RestaurantCard web component
 */
