let app = angular.module('restaurantApp', []);

app.controller('restaurantController', function($scope, $http) {


    $scope.topratedRestaurants = [];
    $scope.restaurants = [];

    $http.get('top-rated-restauransts.json')
        .then(function(response) {
            $scope.topratedRestaurants = response.data;
            console.log("Top rated: ", $scope.topratedRestaurants)
        });

        $http.get('restaurants.json')
        .then(function(response) {
            $scope.allRestaurants = response.data;  // Az összes étterem elérhetővé válik
            $scope.loadMoreRestaurants();  // Azonnal betöltjük az első három éttermet
        });

    $scope.loadMoreRestaurants = function() {
        let remainingRestaurants = $scope.allRestaurants.slice($scope.restaurants.length);
        let nextBatch = remainingRestaurants.slice(0, 3);  // Csak a következő három étterem
        $scope.restaurants = $scope.restaurants.concat(nextBatch);
    };

    $scope.loadAllRestaurants = function() {
        // Betöltjük az összes éttermet
        $scope.restaurants = $scope.allRestaurants.slice();
    };
 
    
});
